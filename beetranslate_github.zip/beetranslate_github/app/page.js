
'use client';
import { useState } from 'react';

export default function Page() {
  const [text, setText] = useState('');
  const [translated, setTranslated] = useState('');
  const [definition, setDefinition] = useState('');
  const [example, setExample] = useState('');

  const translate = () => {
    if (!text.trim()) return;
    setTranslated('Example translation of: ' + text);
    setDefinition('Sample dictionary definition for the entered word.');
    setExample('This is an example sentence using the word.');
  };

  const speak = (accent) => {
    const utter = new SpeechSynthesisUtterance(translated || text);
    utter.lang = accent;
    speechSynthesis.speak(utter);
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '700px', margin: '0 auto' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>BeeTranslate</h1>
      <textarea
        rows={4}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type text here..."
        style={{ width: '100%', padding: '1rem', border: '2px solid black', borderRadius: '10px' }}
      />
      <button onClick={translate} style={{ marginTop: '1rem', padding: '0.7rem 1.4rem', border: '2px solid black', background: '#fde047' }}>
        Translate
      </button>

      {translated && (
        <div style={{ marginTop: '2rem', padding: '1rem', border: '2px solid black', borderRadius: '10px', background: '#facc15' }}>
          <h2 style={{ fontWeight: 'bold' }}>Translation</h2>
          <p>{translated}</p>

          <h2 style={{ fontWeight: 'bold', marginTop: '1rem' }}>Dictionary</h2>
          <p>{definition}</p>

          <h2 style={{ fontWeight: 'bold', marginTop: '1rem' }}>Example Usage</h2>
          <p>{example}</p>

          <h2 style={{ fontWeight: 'bold', marginTop: '1rem' }}>Pronunciation</h2>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button onClick={() => speak('en-US')} style={{ border: '2px solid black', padding: '0.4rem' }}>US</button>
            <button onClick={() => speak('en-GB')} style={{ border: '2px solid black', padding: '0.4rem' }}>UK</button>
            <button onClick={() => speak('en-AU')} style={{ border: '2px solid black', padding: '0.4rem' }}>AU</button>
            <button onClick={() => speak('id-ID')} style={{ border: '2px solid black', padding: '0.4rem' }}>ID</button>
          </div>
        </div>
      )}
    </div>
  );
}
