
export const metadata = { title: "BeeTranslate" };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ backgroundColor: '#fef08a', color: 'black' }}>{children}</body>
    </html>
  );
}
